import React from "react";

function Heading(){
    return  <h1 className="heading">Rajesh componet</h1>
}
export default Heading;