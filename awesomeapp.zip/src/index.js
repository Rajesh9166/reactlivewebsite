import React from "react";
import ReactDom from "react-dom";
//import App from './App';
import TodoList from "./TodoList";
import "./index.css";

ReactDom.render(
  <>
    <TodoList />
  </>,
  document.getElementById("root")
);

// let fname = 'Good Morning';
// let curDate = new Date(2021,11,5,19);
// curDate = curDate.getHours();
// if(curDate >= 1 && curDate<12){
//   fname = 'Good Morning';
// }else if(curDate >= 12 && curDate < 19){
//   fname = 'Good Afternoon';
// }else{
//   fname = 'Good Night';
// }
// ReactDom.render(
//   <>
//     <h1 className="heading">Hello Sir,{`${fname} ${curDate}`}</h1>
//   </>,
//   document.getElementById('root'));

// const fname = 'Rajeshvw ';
// const lname = 'Jangid';
// const img1 = "https://picsum.photos/200/300";
// const img2 = "https://picsum.photos/250/300";
// const img3 = "https://picsum.photos/300/300";
// const link = "https://rajeshjangid.com";
// const img_div = {
//   display: "flex",
//   justifyContent: "center"
//   }
// ReactDom.render(
//   <>
//     <h1 className="heading">Hello {`${fname} ${lname}`}</h1>
//     <div style={img_div}>
//      <img src={img1} alt="Images"/>
//      <img src={img2} alt="Images"/>
//      <a href={link} target="_blank">
//       <img src={img3} alt="Images"/>
//       </a>
//       </div>
//     </>,
//   document.getElementById('root'));
